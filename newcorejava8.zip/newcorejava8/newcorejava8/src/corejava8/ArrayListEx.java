package corejava8;

import java.util.ArrayList;
import java.util.Arrays;

public class ArrayListEx {

	public static void main(String[] args) {
		ArrayList<String> a= new ArrayList<>(Arrays.asList("rajesh", "anisha"));
		
	}

}
