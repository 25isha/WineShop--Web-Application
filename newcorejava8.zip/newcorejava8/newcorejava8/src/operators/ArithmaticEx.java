package operators;

public class ArithmaticEx {

	public static void main(String[] args) {
		
		int i=10, j=20, sum;
		
		System.out.println("Addition of number: " +(i+j));
		System.out.println("Subtraction of number: " +(i-j));
		System.out.println("Multiplication of number: " +(i*j));
		System.out.println("Division of number: " +(i/j));
		System.out.println("Modulo of number: " +(i%j));
		
		

	}

}
