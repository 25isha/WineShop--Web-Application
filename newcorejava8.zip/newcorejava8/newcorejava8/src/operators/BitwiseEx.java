package operators;



public class BitwiseEx {

	public static void main(String[] args) {
		
		
		 int number1 = 10, number2 = 1, result;

		    
		  System.out.println(number1 | number2);
		  System.out.println(number1 & number2);
		  System.out.println(number1 ^ number2);
		  System.out.println(~ number2);
		    		   
		  // We can write program bitwise in 2 types
		  
		/*int a = 15;
		int b = 25;
		
		System.out.println(a&b);// AND (&) 
		System.out.println(a^b);//Bitwise XOR (^)
		System.out.println(a|b);//Bitwise OR (|) 
		System.out.println(~b);//Bitwise Complement (~)*/
	}

}
