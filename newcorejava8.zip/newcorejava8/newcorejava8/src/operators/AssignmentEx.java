package operators;

public class AssignmentEx {

	public static void main(String[] args) {
		
		int i=5;
		int j=10;
		
		System.out.println(i=j);

		System.out.println(i+=j);
		
		System.out.println(i*=j);
		
		System.out.println(i/=j);
		
		System.out.println(i%=j);
		
		System.out.println(i^=j);
		
		System.out.println(i>>=j);
		
		System.out.println(i<<=j);
		
		// 2nd way to write program
		/*b = a;
	    System.out.println("var using =: " + a);

	    
	    b += a;
	    System.out.println("var using +=: " + b);

	    b *= a;
	    System.out.println("var using *=: " + b);
	    
	    b /= a;
	    System.out.println("var using /=: " + b);
	    
	    b ^= a;
	    System.out.println("var using ^=: " + b);
	    
	    b %= a;
	    System.out.println("var using : " + b);*/
	  }
		
		
	}


