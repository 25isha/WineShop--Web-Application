package operators;
import java.util.Scanner;
public class RelationalEx {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int age =(int) s.nextLong();
		System.out.println("print:" +age);
	}

}
