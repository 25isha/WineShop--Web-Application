package operators;

public class LogicalEx {

	public static void main(String[] args) {
	
		 boolean b = true;
		 boolean b1 = false;
		 
	
		 
		 System.out.println("AND Operator is :" +(b &&b1));
		 System.out.println("OR Operator is :" +(b||b1));
		 System.out.println("NOt Operator is :" +!(b&&b1));
		
			

	}

}
