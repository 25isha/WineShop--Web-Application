package operators;

public class ShiftEx {

	public static void main(String[] args) {
		
		
		int j = 10;
		int i=j>>1;
		System.out.println("right shift operator: " +i);
		
		int i1=j<<1;
		System.out.println("Left shift operator : " +i1);
		
		
		

	}

}
