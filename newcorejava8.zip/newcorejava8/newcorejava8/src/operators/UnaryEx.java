package operators;

public class UnaryEx {

	public static void main(String[] args) {
		
		int x = 3;
		if(x > 2) {
		    if(x > 5) {
		       System.out.println(x = 4); 
		    }else{
		    	System.out.println(x = 2);
		    }
		} else {
			System.out.println(x = 8);
		}
	}

}
