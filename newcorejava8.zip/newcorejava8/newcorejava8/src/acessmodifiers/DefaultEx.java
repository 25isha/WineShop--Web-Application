package acessmodifiers;

public class DefaultEx {

	public static void main(String[] args) {
		
		Demo d= new Demo(8);
		d.display();
		
	}

}
