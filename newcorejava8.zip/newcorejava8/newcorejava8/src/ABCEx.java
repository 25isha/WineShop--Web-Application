
public class ABCEx {

	public static void main(String[] args) {
		int i;
		for(i=1;i<10;i++);
		
		System.out.println(i);
		//?:    
		int k,j;
		k=10;
		j=13;
		int b=(k<j)?k:j;
		System.out.println(b);
	}

}
