package filetopic;

import java.io.Serializable;

// 1st create bike class
public class BikeEx implements Serializable{

	int bNo;
	String bName,bcolor;
	public void display() {
		System.out.println("Bike No: "+bNo);
		System.out.println("Bike No: "+bName);
		System.out.println("Bike No: "+bcolor);
	}
		
	}


