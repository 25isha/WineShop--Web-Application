package inheritance;

public interface ABC{
	void methodABC();

}