package inheritance;

public interface PQR{
	void methodPQR();
	

}