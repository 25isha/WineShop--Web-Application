package inheritance;

public interface XYZ extends ABC,PQR{
	void methodXYZ();

}