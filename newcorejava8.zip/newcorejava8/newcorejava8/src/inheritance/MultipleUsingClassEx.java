package inheritance;

public class MultipleUsingClassEx extends Child1{

	public static void main(String[] args) {
		MultipleUsingClassEx m =new MultipleUsingClassEx();
		m.methodABC();
		m.methodPQR();
		m.methodXYZ();
		
	}
		
	}
