package inheritance;

public class Child1 implements XYZ{
	


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
		public void methodABC() {
			System.out.println("abc");
			
		}

		
		public void methodPQR() {
			System.out.println("pqr");
		}

		
		public void methodXYZ() {
			System.out.println("xyz");
			
		

	}

}
