package basic;

public class DataTpes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		
				byte b=10;
				System.out.println("Byte :"+b);
				int ii=b;
				System.out.println("Widening :"+ii);
				char ch='p';
				System.out.println("Character :"+ch);
				String s="hello";
				System.out.println("String :"+s);
				int i=10000;
				System.out.println("Interger :"+i);
				float f11=i;
				System.out.println("float widening :"+f11);
				byte b1=(byte) i;
				System.out.println("narrowing "+b1);
				float per=89.99f;
				System.out.println("Float :"+per);
				double d=678.890;
				System.out.println("Double :"+d);
				int dd=(int) d;
				System.out.println("narrowing(double->int) :"+dd);
				short s1=345;
				System.out.println("short: "+s1);
				boolean bol=true;
				System.out.println("Boolean:"+bol);
				
				
				

			
	}

}
