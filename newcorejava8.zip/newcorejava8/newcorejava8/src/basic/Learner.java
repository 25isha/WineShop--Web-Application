package basic;

public class Learner {
	
	public void LernerDetails(){
	
		String name="Isha";
		String degree="BE Computer Engineering";
		String location="Navi mumbai";
		int rollnumber=34;
		
		System.out.println("student name : " +name );
		
		System.out.println("student degree: " +degree );
		
		System.out.println("student location: " +location );
		
		System.out.println("student rollnumber: " +rollnumber );
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Learner l=new Learner();
		l.LernerDetails();
		

	}

}

	