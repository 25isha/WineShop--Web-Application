package basic;

public class StringbufferEx {

	

	public static void main(String[] args) {
		
		//String a="isha";
		//String b="Gaikawad";
		
		
		/*System.out.println("lenght of string is:" +a.length());
		System.out.println("uppercase:" + b.toUpperCase());
		System.out.println("lowercase:" + a.toLowerCase());
		System.out.println("this both are equal:" + a.equals(b));
		System.out.println("this both are equal:" + a.equalsIgnoreCase(a));
		System.out.println("uppercase:" + b.toUpperCase());*/
		
		//System.out.println("replace string:" + a.replace(a, b));
		
		
		
		
		
		

	}

	private void toString(String string) {
		// TODO Auto-generated method stub
		
	}

}
