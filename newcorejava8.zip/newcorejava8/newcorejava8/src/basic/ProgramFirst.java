package basic;

public class ProgramFirst {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("welcome");
		String s="isha";
		System.out.println("hello baby:" +s);
		int num1=10,num2=4,sum;
		sum=num1+num2;
		System.out.println("sum is "+num1+" and "+num2+" :" +sum);
	}

}
