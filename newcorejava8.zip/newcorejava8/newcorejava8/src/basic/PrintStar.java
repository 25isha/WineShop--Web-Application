package basic;

public class PrintStar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 
		/*for (int i= 0; i<= 4; i++)  
		{  
		for (int j=0; j<=i; j++)   
		{  
		System.out.print("* ");  
		}   
		System.out.println("");   
		}   
		for (int i=2; i>=0; i--)  
		{  
		for(int j=0; j <= i-1;j++)  
		{  
		System.out.print("*"+ " ");  
		}  
		System.out.println("");
			
		
	}*/
		
		for (int i= 0; i<= 3; i++)  
		{  
		for (int j=1; j<=3; j++)   
		{  
		System.out.print(" ");  
		}      
		for (int i1=0; i1<=i; i1++)  
		{  
		  
		System.out.print(" *");  
		}  
		System.out.println("");
			
		}

}

}