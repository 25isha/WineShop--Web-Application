package basic;

public class OperatorsEx {

	public static void main(String[] args) {
		
		//Unary operator
		int x=5;
		int y=6;
		System.out.println("post increment:" +y++);

	}

}
