package basic;

public class SimpleStringProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="isha";
		System.out.println("string:" +s);

		String s1="gaikawad";
		System.out.println("string surname:" +s1);
		
		
	}

}
