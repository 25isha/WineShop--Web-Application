package basic;

public class LocalVariableEx {
	
	public void studentAge()
	
	{
		int age=40;
		//age=age+40;
		System.out.println("student Age : " +age );
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalVariableEx ex=new LocalVariableEx();
		ex.studentAge();
	}

}
