package exception;
import java.util.Scanner;
import java.util.InputMismatchException;

// create student class.
class StudentManagement extends Exception
{  
	StudentManagement(String error)
    {
		super(error);
	}
}

public class MarksheetProgram {

	public static void main(String[] args) {
	
		

	}

}
