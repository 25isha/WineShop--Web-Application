package exception;

public class ThrowExceptionEx {

	public static void main(String[] args) {
		throw new ArithmeticException("zero");
		//System.out.println("class not found");
		
		

	}

}
