
public class SwitchEx {

	public static void main(String[] args) {

		/*int a= 2;
		switch(a)
		{
		case 1:System.out.println("isha");
		break;
		case 2:System.out.println("gaikawad");
		break;
		
		}*/
		
		/*char ch='i';
		switch(ch) {
		case 'i':System.out.println("isha");
		break;
		
		case 'j':System.out.println("isha G");
		break;
		}*/
		
		String a="additon";
		int c=2;
		int b=3;
		
		switch(a) {
		
		case "a":System.out.println(c+b);
		break;
		case "subtraction":System.out.println(c-b);
		break;
		case "Multiplication": System.out.println(b*c);
		break;

		default:
			System.out.println("No Operation dne");
		}
		
	}


}




